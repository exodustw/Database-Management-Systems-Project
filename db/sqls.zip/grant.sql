GRANT ALL PRIVILEGES ON DBProject.* TO 'dbproject_admin'@'%' WITH GRANT OPTION;
GRANT EXECUTE ON DBProject.* TO 'dbproject_appuser'@'%' WITH GRANT OPTION;