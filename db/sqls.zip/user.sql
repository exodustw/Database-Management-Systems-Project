CREATE USER 'dbproject_admin'@'%' IDENTIFIED BY 'Jws6XcXtTGuMstYV!*RqeDNMCC$LptG^yX#qf4x5';
CREATE USER 'dbproject_appuser'@'%' IDENTIFIED BY '#&K#jeXHFP9p@R6#Syz4bbZvPrk2Xd%GvnHUBEae';